export class accountDetailsModel {
    "accountNumber": number;
    "accountName": string;
    "accountType": string;
    "bank": string;
    "branch": string;
    "ifsc": string;
    "panNumber": number;
    "Tandc": string;
}

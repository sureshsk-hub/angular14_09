// export class photos{
//     imageUrl:[imagemodel]
// }
// export class imagemodel{
//     "image":string;
// }
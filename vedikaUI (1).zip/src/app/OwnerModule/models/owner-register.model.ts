export class registermodel {
    "username":string;
    "firstname":string;
    "lastname":string;
    "email":string;
    "Mobile number":number;
   }
export class SecurityModel {
    "mobilenumber": number;
}
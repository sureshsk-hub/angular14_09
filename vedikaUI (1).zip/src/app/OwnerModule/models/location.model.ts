export class LocationModel {
    "country": string;
    "state": string;
    "city": string;
    "streetAddress": string;
    "zipcode": number;
}

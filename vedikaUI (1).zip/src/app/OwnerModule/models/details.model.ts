export class DetailsModel {
   "name":string;
    "functionhalldescription": string;
    "functionhalltype": string;
    "functionhallPrice": number;
    "foodtype" : string;
    "maximumguest" : number;
    "briderooms" : string;
    "ownerFirstName": string;
    "ownerLastName": string;
    // "amenities": [];
    "parking":string;
    "internet":string;
    "nosmoking":string;
    "airconditioning":string;
    "lightingsystem":string;
    "dancefloor":string;
    "noalcohol":string;
    "soundsystem":string;
    // "eventType": [];
    "banquethall":string;
    "partyroom":string;
    "conference":string;
    "performance":string;
    "weddinghall":string;
    "eventspace":string;
    "nightclub":string;

}

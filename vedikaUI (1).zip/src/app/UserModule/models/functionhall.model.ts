export class FunctionHallModel {
    functionHallName: string;
    ownerFirstName: string;
    ownerLastName: string;
    ownerId: string;
    street: string;
    state: string;
    city:  string;
    zipcode: number;
}




